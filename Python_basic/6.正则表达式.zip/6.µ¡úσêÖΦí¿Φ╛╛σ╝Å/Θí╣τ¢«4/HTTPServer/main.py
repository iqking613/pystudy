'''
name : lianyuxue
date : 2020-04-02
func : HTTPServer + Frame 版本

'''
from HTTPServer.HttpServer import HTTPServer
from HTTPServer.setting import *
import sys

def main():
    # 将要使用的模块导入进来
    sys.path.insert(1, MODULE_PATH)
    # 调取模块
    m = __import__(MONDULE)
    # 调取模块类/属性
    application = getattr(m, APP)

    httpd = HTTPServer(application)
    httpd.bind(HOST, PORT)
    httpd.serve_forever()



if __name__ == '__main__':
    main()







