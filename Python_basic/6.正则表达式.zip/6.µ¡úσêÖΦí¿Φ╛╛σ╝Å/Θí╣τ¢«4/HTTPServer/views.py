import time

def show_time():
    return time.ctime()

def say_hello():
    return "hello world"

def say_bye():
    return "Good Bye"