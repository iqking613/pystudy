#coding=utf-8
'''
name : lianyuxue
date : 2020-04-02
func : HttpServer
'''
from socket import *
import sys
from threading import Thread
import signal
import re

# 处理Http请求类
class HTTPServer(object):
    def __init__(self, application):
        self.sockfd = socket()
        self.sockfd.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
        # 获取模块接口
        self.application = application

    def bind(self, host, port):
        self.ip = host
        self.port = port
        self.sockfd.bind((self.ip, self.port))

    # 启动服务器
    def serve_forever(self):
        self.sockfd.listen(5)
        print("Listen the port %d..." % self.port)
        while True:
            connfd, addr = self.sockfd.accept()
            print("Connect from ", addr)
            handle_client = Thread(target=self.client_handler, args=(connfd,))
            # 守护线程
            handle_client.setDaemon(True)
            handle_client.start()

    def client_handler(self, connfd):
        # 接收浏览器请求request
        request = connfd.recv(4096)
        # 可以分析请求头和请求体
        request_lines = request.splitlines()
        # 获取请求行
        request_line = request_lines[0].decode('utf-8')
        # 获取请求方法和请求内容           # r'^([A-Z]+)\s+(/\S*)  ===>>>   [('GET', '/')]
        # 方法一
        try:
            env = re.match(r'(?P<METHOD>[A-Z]+)\s+(?P<PATH_INFO>/\S*)', request_line).groupdict()
        except:
            response_headlers = "HTTP/1.1 500 内部服务器错误"
            response_headlers += "\r\n"
            response_body = "内部服务器错误"
            response = response_headlers + response_body
            connfd.send(response.encode())
        # 将env给Frame处理，得到返回内容
        response = self.application(env)
        # 响应客户端
        if response:
            connfd.send(response.encode())
            connfd.close()

        # 方法二
        # methond, filename = re.findall(r'^([A-Z]+)\s+(/\S*)', request_line)[0]
        #将解析内容合成字典给web frame使用
        # env = {'METHOD':methond, 'PATH_INFO':filename}












