# httpserver配置

HOST = '0.0.0.0'
PORT = 8000

# 设置要使用的模块和应用
# 设置模块路径
MODULE_PATH = '.'
# 设置模块名称
MONDULE = 'WebFrame'
# 设置使用的应用
APP = 'app'









