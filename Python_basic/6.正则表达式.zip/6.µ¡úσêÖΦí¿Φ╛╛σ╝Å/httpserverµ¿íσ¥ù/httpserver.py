from http.server import BaseHTTPRequestHandler, HTTPServer

class requestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        # print(self.headers)
        # print(self.request)
        print(self.path)
        fd = open('test.html', 'rb')
        content = fd.read()
        # print(content)
        # 组织response
        self.send_response(200)
        self.send_header('Content-Type', 'text/html')
        self.end_headers()
        self.wfile.write(content)

    def do_POST(self):
        pass

address = ('0.0.0.0', 8888)

# 生成httpserver对象
httpd = HTTPServer(address, requestHandler)
# 启动服务器
httpd.serve_forever()


