import re

def main():
    try:
        with open("./test.txt",'rb') as src:
            data = src.read(1024).decode()
            # 元字符定义
            # 大写字母开头
            # s = r'\b[A-Z][\._0-9a-zA-Z]*'
            # * 匹配0个或多个
            s = r'-?\d+\.?/?\d*%?'
            print(re.findall(s, data))

            # regex = re.compile(s)
            # obj = regex.finditer(data)
            # for i in obj:
            #     print(i.group(),end=',')

    except Exception as err:
        print(err)

if __name__ == '__main__':
    main()





