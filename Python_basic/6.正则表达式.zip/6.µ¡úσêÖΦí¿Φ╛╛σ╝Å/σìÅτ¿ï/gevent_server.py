import gevent
# 在socket导入之前使用
from gevent import monkey
monkey.patch_all()
from socket import *
from time import ctime


def server(port):
    s = socket()
    s.setsockopt(SOCK_STREAM,SO_REUSEADDR, 1)
    s.bind(('0.0.0.0', port))
    s.listen(5)
    while True:
        connfd, addr = s.accept()
        print("Connect from ", addr)
        # 处理客户端请求
        gevent.spawn(handler, connfd)

def handler(connfd):
    while True:
        data = connfd.recv(1024).decode()
        if not data:
            break
        print("Receive :", data)
        connfd.send(ctime().encode())
    connfd.close()


if __name__ == '__main__':
    server(8888)

