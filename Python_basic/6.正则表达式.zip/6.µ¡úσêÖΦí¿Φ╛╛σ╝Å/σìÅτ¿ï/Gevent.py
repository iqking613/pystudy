import gevent

def foo(a):
    print("Running in foo", a)
    gevent.sleep(2)
    print("switch to foo again")

def bar(a):
    print("Running in bar", a)
    gevent.sleep(3)
    print("switch to bar again")

# 生成协程
f = gevent.spawn(foo,1)
b = gevent.spawn(foo,2)

# 回收协程
gevent.joinall([f, b])
