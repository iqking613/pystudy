from greenlet import greenlet


def func1():
    print("func1 first")
    gr2.switch()
    print("func2 second")


def func2():
    print("func2 first")
    gr1.switch()
    print("func2 second")


gr1 = greenlet(func1)
gr2 = greenlet(func2)
gr1.switch()