from Server.db.word import sys_word
import time
import struct
class Func_Server():
    def __init__(self, db, connfd):
        self.connfd = connfd
        self.db = db
        self.word = sys_word(self.db)
    # 注册
    def register(self, name, passwd, email):
        data = self.word.user_insert(name, passwd, email)
        if data:
            self.connfd.send(b'OK')
        else:
            self.connfd.send(b'ERR')

    # 登陆
    def login(self, name, passwd):
        data = self.word.user_select(name)
        if data:
           data = self.word.passwd_select(name, passwd)
           if data:
               self.connfd.send(b"OK")
           else:
                self.connfd.send("密码不正确".encode())
        else:
            self.connfd.send("用户不存在".encode())

    # 查词
    def select(self, name, word):
        data = self.word.word_select(word.split())
        if data:
            msg = ""
            for i in data:
                msg += i[0]
                msg += " "
            self.connfd.send(msg.encode())
            self.word.history_insert(name, word)
        else:
            self.connfd.send("没有该词汇".encode())

    # 历史记录
    def history(self, name):
        data = self.word.history_select(name)
        if data:
            self.connfd.send(b'OK')
            time.sleep(0.1)
            for i in data:
                msg = "%s %s %s" % (i[0],i[1],i[2].strftime("%Y-%m-%d %H:%M:%S"))
                # 解决粘包问题
                # 打包数据长度
                mag = msg.encode()
                mag_len = len(mag)
                mag_len_stru = struct.pack('i', mag_len)
                self.connfd.send(mag_len_stru)
                # 发送数据内容
                self.connfd.send(msg.encode())
            time.sleep(0.1)
            self.connfd.send(b'EXIT')
        else:
            self.connfd.send("无历史记录".encode())

