from socket import *
import sys, os,time
from sock.Socket import Socket_Server
from func.Function import Func_Server
from db.Connect import Connect
import signal

def main():
    # 创建TCP套接字
    sockfd = Socket_Server('0.0.0.0',8888,DEFIND_SOCK_N=SOCK_STREAM)
    # 处理僵死进程
    signal.signal(signal.SIGCHLD, signal.SIG_IGN)
    print("运行中")
    while True:
        try:
            connfd, addr = sockfd.accept()
        except KeyboardInterrupt:
            sockfd.close()
            sys.exit("服务器退出")
        except Exception as e:
            print(e)
            continue
        print("客户端{}已连接".format(addr))

        # 创建父子进程
        pid = os.fork()
        if pid == 0:
            # 子进程运行代码
            sockfd.close()
            db, status = Connect()
            if status == "连接成功":
                print(status)
            else:
                print(status)
                sys.exit(0)
            # 调取子进程功能类
            func = Func_Server(db, connfd)
            try:
                while True:
                    data = connfd.recv(1024).decode().split()
                    if (not data) or data == 'quit':
                        print("客户端退出")
                        sys.exit(0)
                    elif data[0] == 'R':
                        func.register(data[1], data[2], data[3])
                    elif data[0] == 'L':
                        print(data[1], data[2])
                        func.login(data[1], data[2])
                    elif data[0] == 'S':
                        msg = ' '.join(data[2:])
                        func.select(data[1], msg)
                    elif data[0] == 'H':
                        print(data[1])
                        func.history(data[1])
            except ConnectionResetError as err:
                print("客户端退出")
                sys.exit(0)
        else:
            # 当子进程结束，端口客户端连接
            connfd.close()
            continue


if __name__ == '__main__':
    main()




