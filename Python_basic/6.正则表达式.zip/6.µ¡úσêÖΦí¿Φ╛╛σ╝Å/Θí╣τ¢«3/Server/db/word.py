import time
class sys_word():
    def __init__(self, db):
        self.db = db

    def data_insert(self, name, Explanation):
        SQL =  "insert into word (name, Explanation) values (%s, %s)"
        self.db.idu(SQL, L=[name, Explanation])

    def OPEN(self, file):
        try:
            i = 0
            with open(file, 'rb') as src:
                while True:
                    data = src.readline().decode('gbk')
                    if not data:
                        self.db.commit()
                        break
                    # print(data.split(',')[0].strip('\''))
                    self.data_insert(data.split(',')[0].strip('\''),data.split(',')[1].strip('\''))
                    print(i)
                    i += 1
        except Exception as err:
            print("打开文件失败{}".format(err))

    # 用户注册
    def user_insert(self, name, passwd, email):
        SQL = "insert into user (name, passwd, email) values (%s, %s, %s)"
        data = self.db.idu(SQL, L=[name, passwd, email])
        self.db.commit()
        return data

    # 用户登陆
    def user_select(self,name):
        SQL = "select name,passwd from user where name=%s"
        data = self.db.sall(SQL, L=[name])
        return data

    # 登陆校验
    def passwd_select(self, name, passwd):
        SQL = "select name,passwd from user where name=%s and passwd=%s"
        data = self.db.sall(SQL, L=[name, passwd])
        return data

    # 查词
    def word_select(self, word):
        SQL = "select Explanation from word where name in%s"
        data = self.db.sall(SQL, L=[tuple(word)])
        return data

    # 历史记录插入
    def history_insert(self, name, word):
        SQL = "insert into history (name, word) values (%s, %s)"
        data = self.db.idu(SQL, L=[name, word])
        if data:
            self.db.commit()
    # 历史记录查询
    def history_select(self,name):
        SQL = "select name,word,time from history where name=%s"
        data = self.db.sall(SQL, L=[name])
        return data



