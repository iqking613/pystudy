from socket import *

class Socket_Server(object):
    def __init__(self, IP, PORT, DEFLND_AF_N=AF_INET, DEFIND_SOCK_N=SOCK_DGRAM):
        self.IP = IP
        self.PORT = PORT
        self.ADDR = (self.IP, self.PORT)
        self.DEFIND_AF_N = DEFLND_AF_N
        self.DEFIND_SOCK_N = DEFIND_SOCK_N
        # 创建套接字
        self.sock = socket(self.DEFIND_AF_N, self.DEFIND_SOCK_N)
        # 端口重用
        self.sock.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
        # 绑定地址
        self.sock.bind(self.ADDR)
        # 监听
        self.sock.listen(5)

    def accept(self):
        self.connfd, addr = self.sock.accept()
        return self.connfd, addr

    # def recv(self):
    #     data = self.connfd.recv(1024)
    #     return data
    #
    # def send(self, msg):
    #     self.connfd.send(msg)

    def close(self):
        self.sock.close()
