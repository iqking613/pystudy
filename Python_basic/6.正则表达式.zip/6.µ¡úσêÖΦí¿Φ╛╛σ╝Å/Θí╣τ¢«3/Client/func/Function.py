import time
import struct

class Func_Client():
    def __init__(self, sockfd):
        self.sockfd = sockfd

    # 登陆
    def login(self, name, passwd):
        msg = "L %s %s" % (name, passwd)
        self.sockfd.send(msg.encode())

    # 注册
    def register(self, name, passwd, email):
        msg = "R %s %s %s" % (name, passwd, email)
        self.sockfd.send(msg.encode())

    # 退出
    def quit(self):
        self.sockfd.send('quit'.encode())

    # 查词
    def select(self, name, word):
        msg = "S {name} {word}".format(name=name,word=word)
        self.sockfd.send(msg.encode())
        data = self.sockfd.recv()
        print(data.decode())

    # 历史记录
    def history(self, name):
        msg = "H %s" % name
        self.sockfd.send(msg.encode())
        data = self.sockfd.recv()
        if data == b'OK':
            while True:
                # 接收数据报头长度
                line = self.sockfd.recv(4)
                if line == b'EXIT':
                    break
                line_len = struct.unpack('i', line)[0]
                # 拼接数据消息
                all_msg = b''
                while True:
                    if line_len < 1024:
                        line_data = self.sockfd.recv(line_len)
                        all_msg += line_data
                        print(all_msg.decode())
                        break
                    else:
                        line_data = self.sockfd.recv()
                        all_msg += line_data
                        line_len -= 1024
        else:
            print(data.decode())

