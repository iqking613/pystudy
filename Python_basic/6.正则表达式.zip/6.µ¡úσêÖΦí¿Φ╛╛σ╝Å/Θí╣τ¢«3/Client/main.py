from sock.Socket import Socket_Client
from func.Function import Func_Client
import sys


def main():
    try:
        sockfd = Socket_Client('172.16.2.220', 8888)
        sockfd.connect()
    except ConnectionRefusedError as err:
        print("服务端连接失败，可能原因{}".format(err))
        sys.exit(0)
    # 调取功能类
    func = Func_Client(sockfd)
    while True:
        print("==========================")
        print("| login--------->>登陆    |")
        print("| register------>>注册    |")
        print("| quit---------->>退出    |")
        print("==========================")
        cmd = input("请输入指令:")
        if cmd.strip() == 'login':
            count = 1
            while True:
                name = input("请输入登陆用户:")
                if not name:
                    print("用户不能为空")
                    continue
                passwd = input("请输入登陆密码:")
                if not passwd:
                    print("密码不能为空")
                    continue
                func.login(name, passwd)
                data = sockfd.recv()
                if data == b'OK':
                    print("登陆成功")
                    while True:
                        print("==========================")
                        print("| select------->>查词    |")
                        print("| history------>>历史记录|")
                        print("| quit---------->>注销   |")
                        print("==========================")
                        cmd = input("请输入指令:")
                        if cmd.strip() == 'select':
                            while True:
                                word = input("请输入查词指令:")
                                if not word:
                                    print("不能为空")
                                    continue
                                elif word == '##':
                                    break
                                func.select(name, str(word))
                        elif cmd.strip() == 'history':
                           func.history(name)
                        elif cmd.strip() == 'quit':
                            print("{}已退出".format(name))
                            break
                    break
                else:
                    print(data.decode())
                    if count == 3:
                        print("已连续3次输入错误，请重新选择")
                        break
                    count += 1
                    continue
        elif cmd.strip() == 'register':
            name = input("请输入用户:")
            if not name:
                print("用户不能为空")
                continue
            passwd = input("请输入密码:")
            if not passwd:
                print("密码不能为空")
                continue
            email = input("请输入邮箱:")
            if not email:
                print("邮箱不能为空")
                continue
            func.register(name, passwd, email)
            data = sockfd.recv()
            if data == b'OK':
                print("注册成功")
            else:
                print("注册失败,用户名重复")
        elif cmd.strip() == 'quit':
            func.quit()
            print("已退出")
            sys.exit(0)

if __name__ == '__main__':
    main()


