from socket import *

class Socket_Client():
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.addr = (self.host, self.port)
        self.sockfd = socket()

    def connect(self):
        self.sockfd.connect(self.addr)

    def send(self, msg):
        self.sockfd.send(msg)

    def recv(self, n=1024):
        data = self.sockfd.recv(n)
        return data