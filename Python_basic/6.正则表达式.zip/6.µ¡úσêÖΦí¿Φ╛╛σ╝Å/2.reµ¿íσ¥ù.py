import re

# compile
regex = re.compile(r'(?P<Dog1>ab)c(?P<Dog2>def)')
# regex 对象属性
print(regex.flags)
print(regex.groups)
print(regex.groupindex)

# 1.findall
# pattern = r'([A-Z])(\S+)'

# re调用
# l = re.findall(pattern, 'abcd@163.com')
# print(l)

# compiile对象调用
# regex = re.compile(pattern)
# l = regex.findall("Hello World",4)
# print(l)

# 2.split
# l = re.split(r'\s+', "Hello   world")
# print(l)

# 3.sub
# l = re.sub(r'\s+',"##", "This is a boy", 2)
# print(l)

# 4.subn
# l = re.subn(r'\s+',"##", "This is a boy")
# print(l)

# 5.finditer
# obj = re.finditer(r'(ab)cdef', 'abcdef')
# obj = re.finditer(r'\d+', '2008年，512情人节，08年奥运会')
# print(obj)
# # 迭代出的内容是match对象
# for i in obj:
#     print(dir(i))
#     print(i.span())
#     print(i.group())

# 6.fullmatch
# try:
#     obj = re.fullmatch(r'\w+',"abc#1234")
#     print(obj.group())
# except AttributeError as e:
#     print(e)

# 7.match
# try:
#     obj = re.match(r'foo',"foo, food on th table")
#     print(obj.group())
# except AttributeError as e:
#     print(e)

# 8.search
# try:
#     obj = re.search(r'foo', "Foo, foood, foo, fothe")
#     print(obj.group())
# except AttributeError as e:
#     print(e)

