import re
import time
from Mysql import Mysql_Python as mydb

def Connect():
    db = mydb(host='172.16.8.2', user='root', password='123456', port=3306, database='index_fpqqlsh')
    return db

def insert_data(db, fpqqlsh, log):
    sql = "insert into fwqxx_fpqqlsh (fpqqlsh,log) values (%s, %s)"
    db.idu(sql, L=[fpqqlsh, log])

def getmessage():
    db = Connect()
    status = db.open()
    if status == "连接成功":
        print(status)
    else:
        print(status)
        return 0
    with open('catalina.2020-03-20.out', 'r', encoding='gbk') as src:
        datas = ''
        status = False
        for i in src:
            # 头部
            start = re.findall(r".*<business id='FPKJ' comment='发票开具'>.*", i)
            # 底部
            end = re.findall('</COMMON_FPKJ_XMXXS></REQUEST_COMMON_FPKJ></business>', i)
            if start:
                # 获取流水号
                fpqqlsh = re.search(r'<FPQQLSH>(\w{20})</FPQQLSH>', start[0]).group(1)
                print(fpqqlsh)
                datas += str(start[0])
                status = True
                continue
            if status:
                datas += str(i)
            if end:
                insert_data(db, fpqqlsh, datas)
                status = False
                datas = ''








if __name__ == '__main__':
    getmessage()
