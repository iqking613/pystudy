from Mysql import Mysql_Python as mydb
import os
import time
import threading
import datetime
import re

def Connect():
    db = mydb(host='172.16.8.2', user='root', password='123456', port=3306, database='index_fpqqlsh')
    # db = mydb(host='10.10.50.3', user='skdata', password='Xx6%0e!s', port=3306, database='skdata')
    status = db.open()
    return db, status

class Thread(threading.Thread):
    def __init__(self, func, name, args=(), kwargs={}):
        # 重写Thread
        threading.Thread.__init__(self)
        self.func = func
        self.name = name
        self.args = args
        self.kwargs = kwargs

    def run(self):
        print("开始子进程:", self.name)
        print("子线程PID:", os.getppid())
        self.func(*self.args, **self.kwargs)
        print("结束进程:")

def GET_Message(file, List_data):
    state = True
    with open(file, 'rb') as src:
            # 报文拼接
            datas = ''
            # 状态
            status = False
            # 记录
            sum = 0
            # 开始记录耗时
            start_time = datetime.datetime.now()
            print("开始时间:", start_time)
            while True:
                i = src.readline().decode(encoding='gbk', errors='ignore')
                if not i:
                    state = False
                    end_time = datetime.datetime.now()
                    print("结束时间", end_time)
                    time_cost = end_time - start_time
                    print("耗时:{}".format(time_cost))
                    print("读取{}记录".format(sum))
                    break
                if re.findall(r"<business id='FPKJ' comment='发票开具'>", i):
                    # 获取读取时间
                    local_time = time.time()
                    # 获取流水号
                    fpqqlsh = re.search(r'<FPQQLSH>(\w{20})</FPQQLSH>', i).group(1)
                    print(time.ctime(), fpqqlsh)
                    datas += i
                    status = True
                    continue
                if status:
                    datas += i
                if re.findall('</COMMON_FPKJ_XMXXS></REQUEST_COMMON_FPKJ></business>', i):
                    tup = (fpqqlsh, datas)
                    List_data.append(tup)
                    status = False
                    datas = ''
                    sum += 1

def Insert(db, fpqqlsh, log_data):
    select_time = time.time()
    SQL = "insert into dj_fpqqlsh (fpqqlsh,select_time,log) values (%s, from_unixtime(%s), %s)"
    args = [fpqqlsh, select_time, log_data]
    db.idu(SQL, args)

def run(db, List_data):
    t = time.time()
    while True:
        # if state == False:
        #     print("run 线程被结束")
        #     break
        if List_data:
            new_time = time.time()
            # print("子线程读取:", len(List_data))
            for i in List_data:
                Insert(db, fpqqlsh=i[0],log_data=i[1])
                List_data.remove(i)
            if new_time >= t:
                db.commit()
        else:
            time.sleep(1)

def main():
    # 数据库连接
    db,status = Connect()
    if status == "连接成功":
        print(status)
    else:
        print(status)
    # 数据列表
    List_data = []
    # 线程列表
    List_Thread = []
    print("主线程PID:",os.getpid())
    file = r'/app/python/test/catalina.2020-03-20.out'
    t1 = Thread(func=GET_Message, name="GET_Messags", args=(file, List_data))
    t2 = Thread(func=run, name='run', args=(db, List_data))
    List_Thread.append(t1)
    # List_Thread.append(t2)
    t1.start()
    # t2.start()
    for i in List_Thread:
        i.join()
        print(i,"被结束")

    # print("主线程结束")
    # db.commit()
    # db.close()
if __name__ == '__main__':
    main()

# 耗时:0:01:48.956576

# 读取3088记录
# 耗时:0:01:58.070232
# 2981

# 耗时:0:01:40.456304
# 读取1349记录
# 4329
# 耗时:0:01:09.372485
# 读取1349记录

# 耗时:0:02:06.724874
# 读取598记录
# 4927

# 耗时:0:02:37.044944
# 读取3231记录
# 8030

# 耗时:0:01:59.746706
# 读取2400记录
# 10376

# 结束时间 2020-03-22 10:10:03.566389
# 耗时:0:01:21.957876
# 读取2400记录

# 结束时间 2020-03-22 14:19:34.431144
# 耗时:0:01:16.713855
# 读取2400记录

# 耗时:0:01:20.319212
# 读取2400记录

# 耗时:0:01:22.553241
# 读取2400记录

# 耗时:0:01:49.146061
# 读取1903记录
# 12270

# 耗时:0:02:00.520637
# 读取1971记录
# 14239

