import signal
import time


import time
t=time.time()
while True:
    print(time.time(),t)
    tt=time.time()
    if t+1<=tt:    #time() 返回浮点型，不能精确的等于1秒（间隔时间）故用<=，或者进行取整处理
        print("--------select-------",tt)
        t=time.time()
#            break
    else:
        pass
        # print('do not select',time.time())