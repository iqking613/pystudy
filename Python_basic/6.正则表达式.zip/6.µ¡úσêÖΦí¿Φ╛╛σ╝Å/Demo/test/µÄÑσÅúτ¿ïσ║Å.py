import  re


def getAddress():
    start = input("请输入接口:")

    with open('1.txt', 'r') as src:
        while True:
            data = ''
            # 获取每一段内容
            for line in src:
                if line != '\n':
                    data += line
                else:
                    break
            # 文件结尾跳出循环
            if not data:
                break
            # 匹配每段首个字母单词
            PORT = re.match(r'\S+', data).group()
            # 判断是否为目标段
            if PORT == start:
                pattern = r'inet addr:(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
                addr = re.search(pattern, data).group(1)
                print(addr)
# 先判断首个字母是否是接口名称，如果是，则继续读取，匹配到inet addr:172.16.2.220后返回，到下一个空行结束
#                             如果不是，则读取下一个空行的首个字母，


if __name__ == '__main__':
    getAddress()