import re

pattern = r'(?P<dog>ab)cd(?P<pig>ef)'
regex = re.compile(pattern)

# 获取match对象
obj = regex.search("abcdefghijklmn", 0, 9)

# match对象属性
print(obj.pos)  # 目标字符串的起始位置
print(obj.endpos)   # 目标字符串的结束位置
print(obj.re)       # 正则表达式
print(obj.string)   # 目标字符串
print(obj.lastgroup)    # 最后一组的名称
print(obj.lastindex)    # 最后一组是第几组

# match对象方法
print(obj.span())   # 匹配到内容的起止位置
print(obj.start())  # 匹配到内容的开始位置
print(obj.end())    # 匹配到内容的结束位置
print(obj.group())  # 获取match对象对应的匹配内容，赋值1，2，3为第几个子组匹配到的内容字串
print(obj.groupdict())  # 获取左右匹配组匹配内容，形成字典，键为组名:值为子组匹配到的内容
print(obj.groups()) # 获取所有字组匹配到的内容
