import re

# 1.IGNORECASE
# pattern = r'Hello'
# IGNORECASE 忽略大小写
# regex = re.compile(pattern, re.IGNORECASE)

# l = regex.findall('hello Hello')
# print(l)

# 2.DOTALL
# DOTALL 元字符 .  能够匹配\n(换行)
s = '''
hello world
nihao Beijing



'''
l = re.findall(r'.+', s, re.DOTALL)
print(l)

# 3.MULTILINE
# MULTILINE 匹配每一行的开头和结尾
# s = '''hello world
# nihao Beijing\nzhangsan nihao
# '''
# # obj = re.search(r'^zhangsan', s, re.MULTILINE)
# obj = re.search(r'world$', s, re.MULTILINE)
# print(obj.group())

# 4.VERBOSE
# VERBOSE 能够给正则添加注释
# pattern = r'''(?P<dog>\w+)  # dog组
# \s+     # 匹配任意多个空格
# (\W+)   # 匹配一些特殊字符
# '''
# s = re.match(pattern, 'hello #$%%%', re.VERBOSE).group()
# print(s)











