import re

# 1. 或
# s = 'csd sdss cs sdd sd'
# print(re.findall('cs | sd', s))

# 2. 匹配单个字符
# s = 'csd sdss cs cdd cad'
# print(re.findall('c.d', s))

# 3.匹配开始位置
# s = 'Jame csd sdss cs cdd cad'
# print(re.findall('^Jame', s))

# 4.匹配结束位置
# s = 'test.jpg'
# print(re.findall('.+jpg$', s))

# 5.匹配重复
# s = '5cdefac&65abbbbree'
# print(re.findall('ab*', s))

# 6.匹配重复
# s = '5cdefabcbb&65abbbbree'
# print(re.findall('ab+', s))

# 7.匹配重复
# s = 'a5cdefabcbb&65abbbbree'
# print(re.findall('ab?', s))

# 8.匹配重复
# s = 'a5cdefabcbb&65abbbbree'
# print(re.findall('ab{3}', s))

# 9.匹配重复
# s = 'abb ab abbb abbbbbb abbbbb'
# print(re.findall('ab{3,5}', s))

# 10.匹配字符集
# s = 'Hello world'
# print(re.findall('^[A-Z][a-z]*', s))

# 11.匹配字符集
# s = 'hello12343534world'
# print(re.findall('[^0-9]+', s))

# 12.匹配任意(非)数字字符
# s = '13592392931Hello2323world'
# print(re.findall('^1\d{10}', s))
# print(re.findall('\D+', s))

# 13.匹配任意(非)普通字符
# s = 'Hello$$$1中国共和国'
# print(re.findall('\w+', s))
# print(re.findall('\W+', s))

# 14.匹配(非)空字符
# s = 'hello  world'
# print(re.findall('\w+\s+\w+', s))
# print(re.findall('\S+', 'hello world'))

# 15.匹配起止位置
# s = "Hello world"
# s = "Hello zhangsan"
# print(re.findall('\AHello\s+\w+', s))
# s = 'www.baidu.com'
# print(re.findall('com\Z', s))
# 完全匹配
# s = 'abcd123456'
# print(re.findall('\A\w{4}\d{6}\Z', s))

# 16.匹配(非)单词边界
# s = 'htc01-b'
# print(re.findall(r'\bis\b', 'This is a test'))
# print(re.findall(r'htc\w+\b', s))

# 17.转义
# s = "lianyuxue@chinab2bi.com"
# print(re.findall(r'\w+@\w+\.com', s))
# print(re.findall('\\w+@\\w+\\.com', s))

# 18,贪婪和非贪婪
# re.findall('ab*?', 'abbbbbbbbbbb')
# re.findall('ab+?', 'abbbbbbbbbbb')
# re.findall('ab??', 'abbbbbbbbbbb')
# re.findall('ab{3,5}?', 'abbbbbbbbbbb')

# 19.正则表达式分组
# re.search(r"(ab)cd(ef)", 'abcdef').group()

# re.search(r'\w+\.\w+\.(com|cn)','www.baidu.cn').group()
#
# re.search(r'(?P<dog>w)','wwww').groupdict()
#
# re.search(r'(?P<sz>\d+)\w+(?P=sz)', '123454dfdf343').group()

# 匹配身份证号
s = "13043419920912315x"
# print(re.search(r'^\d{3}\d{3}\d{8}\d{3}(\d|x)', s).group())
print(re.search(r'^\d{3}\d{3}\d{8}\d{3}(\d|x)', s).group())











