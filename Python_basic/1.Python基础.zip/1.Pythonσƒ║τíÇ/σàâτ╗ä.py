# t = tuple()
# t = tuple(range(1, 10, 3))
#
# print(t)

# 练习
# 12.请创建一个元组 T 为 (20,30,40,50,40,30,20)
#     请计算T中元素30的个数
# T = (20, 30, 40, 50, 40, 30, 20)
# Sum = 0
# for i in T:
#     if i == 30:
#         Sum += 1
# print(Sum)






