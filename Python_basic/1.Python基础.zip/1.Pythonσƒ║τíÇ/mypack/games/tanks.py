# mypack/games/tanks.py

def play():
    print("正在玩坦克大战.....")


print("坦克大战模块被加载")