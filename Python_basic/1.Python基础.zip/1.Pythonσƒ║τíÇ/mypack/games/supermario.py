# mypack/games/supermario.py

def play():
    print("正在玩超级玛丽.....")


print("超级玛丽模块被加载")