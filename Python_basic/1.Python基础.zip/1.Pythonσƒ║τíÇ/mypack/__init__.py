# mypack/__init__.py

'''此包mypack用来示意自定义的包

此包含有两个子包:
    games, office
此包含有一个menu模块
'''

def test():
    print("mypack.test()被调用")

print("mypack包被加载")


