def Index1():
    print('1.我的信息')
    print('2.课程信息')
    print('3.查看成绩')
    print('q.注销')



