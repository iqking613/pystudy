def Admin_index():
    print("----------------------")
    print("|用户查询             |")
    print("|       1.用户信息查询|")
    print("|       2.用户成绩查询|")
    print("|用户管理             |")
    print("|       1.添加用户课程|")
    print("|       2.修改用户成绩|")
    print("|       3.删除用户信息|")
    print("----------------------")
# 用户查询
# 用户详细信息查询
def all_info():
    pass

# 用户成绩查询
def all_score():
    pass

# 用户管理
# 添加用户/课程
def add_user():
    pass
# 修改用户成绩
def up_score():
    pass
# 删除用户
def del_user():
    pass
Admin_index()
