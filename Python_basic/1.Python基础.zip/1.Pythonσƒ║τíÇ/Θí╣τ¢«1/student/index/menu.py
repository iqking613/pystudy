def show_menu():

    print("----------------")
    print("|登陆1     注册2|")
    print("----------------")
















