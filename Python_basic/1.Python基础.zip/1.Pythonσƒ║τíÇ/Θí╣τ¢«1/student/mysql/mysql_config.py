# 连接数据库参数
c_host = '172.16.8.2'
c_port = 3306
c_user = 'root'
c_password = '123456'
c_database = 'data'
c_charset = 'utf8'