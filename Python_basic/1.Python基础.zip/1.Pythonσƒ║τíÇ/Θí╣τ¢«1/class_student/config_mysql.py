host = '172.16.8.2'
user = 'root'
password = '123456'
database = 'db5'
charset = 'utf8'




