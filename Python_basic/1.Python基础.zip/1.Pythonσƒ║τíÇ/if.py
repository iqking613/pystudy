# n = int(input("请输入一个整数:"))
#
# if n % 2 == 1:
#     print("这个数是奇数")
# else:
#     print("这个数是偶数")


# u = int(input("请输入一个整数:"))
#
# if u > 100:
#     print(u, "大于100")
# elif u < 0:
#     print(u, "小于0")
# elif 80 < u < 100:
#     print(u, "80~100")
# else:
#     print(u, "及不大于100，也不小于0")

u = int(input("请输入1~4季度:"))

if u == 1:
    print("当前季度有1，2，3月份")
elif u == 2:
    print("当前季度有4，5，6月份")
elif u == 3:
    print("当前季度有7，8，9月份")
elif u == 4:
    print("当前季度有10，11，12月份")
else:
    print("您输入的季度有误")

n = int(input("请输入1~12月份:"))

# if 0 < n < 4:
#     print("您处于1季度")
# elif 3 < n < 7:
#     print("您处于2季度")
# elif 6 < n < 10:
#     print("您处于3季度")
# elif 9 < n < 13:
#     print("您处于4季度")
# else:
#     print("您输入的月份有误")

# if 1 <= n <= 12:
#     if n <= 3:
#         print("您处于1季度")
#     elif n <= 6:
#         print("您处于2季度")
#     elif n <= 9:
#         print("您处于3季度")
#     else:
#         print("您处于4季度")
# else:
#     print("您输入的月份有误")



